
class Data {
    constructor() {
        var min = 300;
        var max = 600;
        this.date = "14:00";
        this.high = Math.random() * (max - min) + min;
        this.low = Math.random() * (this.high - min) + min;
        max = this.high;
        min = this.low;
        this.close = Math.random() * (max - min) + min;
        this.open = Math.random() * (max - min) + min;
    }
}



const canvas = document.querySelector("#canvas");
const ctx = canvas.getContext("2d");
const lowColor = "#FF2929"
const highColor = "#2962FF"
const xStep = 60;
const xWidth = 30;
var xPadding = 30;
var yPadding = 30;
var data = [new Data()]
var minMax = getMinMax()
var min = 0;
var max = 0;

function updateMinMax() {
    var minMax = getMinMax()
    min = minMax.min;
    max = minMax.max;
}
function _loadData(updatedData) {
     data = updatedData
//    for (let i = 0; i < 50; i++) {
//        data.push(new Data())
//    }
console.log(updatedData)
console.log(data)
    updateMinMax()
    resize()
    drawData()
    console.log('Loading data')
    return 50
}
function getMinMax() {
    var lowest = Number.POSITIVE_INFINITY;
    var highest = Number.NEGATIVE_INFINITY;
    var a;
    for (var i = 0; i < data.length; i++) {
        var d = data[i]
        a = [d.high, d.low, d.close, d.open];
        var max = Math.max.apply(Math, a);
        var min = Math.min.apply(Math, a)
        if (max > highest) highest = max
        if (min < lowest) lowest = min
    }
    console.log(highest, lowest);
    return { min: min, max: max }
}


function getYPixel(val) {
    var p = val - max + min
    return p
}



window.addEventListener('load', () => {
    resize()
    drawData()
})

function drawData() {
    var x = 0;
    for (let i = 0; i < data.length - 1; ++i) {
        var d = data[i]
        if (data[i].close > data[i + 1].close)
            ctx.fillStyle = highColor;
        else
            ctx.fillStyle = lowColor;

        ctx.fillRect((x), getYPixel(d.open), (xWidth), getYPixel(d.open - d.close));
        ctx.fillRect((x + xStep / 5), getYPixel(d.low)+200, (xWidth / 4), getYPixel(d.high - d.low)+200);
        x += xStep;
    }
}

function resize() {
    canvas.height = min + max;
    // canvas.width = data.length * xStep;
    // canvas.height = window.innerHeight;
    canvas.width = data.length * xStep;
}
window.addEventListener('resize', () => {
    resize()
    drawData()
})






// loadData([{ "symbol": "AAPL", "open": 144.27, "high": 144.6, "low": 142.79, "close": 142.94, "last": 144.05, "volume": 378444, "date": "2021-09-21T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 144.27, "high": 144.6, "low": 143.21, "close": 142.94, "last": 144.11, "volume": 144208, "date": "2021-09-21T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.03, "high": 143.03, "low": 143.03, "close": null, "last": null, "volume": null, "date": "2021-09-21T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 141.5, "high": 141.745, "low": 141.49, "close": null, "last": null, "volume": null, "date": "2021-09-20T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 144.27, "high": 144.6, "low": 142.79, "close": 142.94, "last": 143.88, "volume": 426757, "date": "2021-09-21T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 142.365, "high": 142.48, "low": 142.31, "close": null, "last": null, "volume": null, "date": "2021-09-20T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 142.2, "high": 142.365, "low": 142.2, "close": null, "last": null, "volume": null, "date": "2021-09-20T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 142.49, "high": 142.545, "low": 142.49, "close": null, "last": null, "volume": null, "date": "2021-09-20T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.78, "high": 144.83, "low": 141.28, "close": 146.06, "last": 141.7, "volume": 1041839, "date": "2021-09-20T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.84, "high": 143.955, "low": 143.765, "close": null, "last": null, "volume": null, "date": "2021-09-20T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.78, "high": 144.83, "low": 142.095, "close": 146.06, "last": 142.205, "volume": 795550, "date": "2021-09-20T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.78, "high": 144.83, "low": 142.48, "close": 146.06, "last": 142.5, "volume": 652002, "date": "2021-09-20T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.78, "high": 144.83, "low": 142.48, "close": 146.06, "last": 142.73, "volume": 485195, "date": "2021-09-20T15:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.78, "high": 144.83, "low": 143.1, "close": 146.06, "last": 143.8, "volume": 235195, "date": "2021-09-20T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 143.78, "high": 143.78, "low": 143.1, "close": 146.06, "last": 143.4, "volume": 3641, "date": "2021-09-20T13:00:00.000Z" },
// { "symbol": "AAPL", "open": 146.07, "high": 146.07, "low": 146.07, "close": null, "last": null, "volume": null, "date": "2021-09-18T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 146.135, "high": 146.215, "low": 146.13, "close": null, "last": null, "volume": null, "date": "2021-09-17T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 146.12, "high": 146.145, "low": 146.09, "close": null, "last": null, "volume": null, "date": "2021-09-17T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 146.78, "high": 146.785, "low": 146.7, "close": null, "last": null, "volume": null, "date": "2021-09-17T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 146.395, "high": 146.54, "low": 146.39, "close": null, "last": null, "volume": null, "date": "2021-09-17T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.06, "high": 149.06, "low": 145.735, "close": 148.79, "last": 146.2, "volume": 1175601, "date": "2021-09-17T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.06, "high": 149.06, "low": 145.875, "close": 148.79, "last": 146.12, "volume": 1061071, "date": "2021-09-17T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.06, "high": 149.06, "low": 146.55, "close": 148.79, "last": 146.75, "volume": 692146, "date": "2021-09-17T15:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.06, "high": 149.06, "low": 146.955, "close": 148.79, "last": 147.22, "volume": 383011, "date": "2021-09-17T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.06, "high": 149.06, "low": 146.18, "close": 148.79, "last": 146.39, "volume": 816279, "date": "2021-09-17T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.795, "high": 148.795, "low": 148.795, "close": null, "last": null, "volume": null, "date": "2021-09-17T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.425, "high": 148.44, "low": 148.4, "close": null, "last": null, "volume": null, "date": "2021-09-16T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.205, "high": 148.235, "low": 148.155, "close": null, "last": null, "volume": null, "date": "2021-09-16T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.1, "high": 148.1, "low": 148.04, "close": null, "last": null, "volume": null, "date": "2021-09-16T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 147.705, "high": 147.745, "low": 147.685, "close": null, "last": null, "volume": null, "date": "2021-09-16T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.4, "high": 148.955, "low": 147.23, "close": 149.03, "last": 148.44, "volume": 610671, "date": "2021-09-16T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.4, "high": 148.955, "low": 147.23, "close": 149.03, "last": 148.23, "volume": 454033, "date": "2021-09-16T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.4, "high": 148.955, "low": 147.23, "close": 149.03, "last": 148.075, "volume": 354537, "date": "2021-09-16T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.4, "high": 148.955, "low": 147.23, "close": 149.03, "last": 147.71, "volume": 292113, "date": "2021-09-16T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.4, "high": 148.955, "low": 147.31, "close": 149.03, "last": 147.69, "volume": 233355, "date": "2021-09-16T15:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.4, "high": 148.955, "low": 147.72, "close": 149.03, "last": 147.83, "volume": 112101, "date": "2021-09-16T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.4, "high": 148.7, "low": 148.295, "close": 149.03, "last": 148.7, "volume": 1007, "date": "2021-09-16T13:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.08, "high": 149.08, "low": 149.08, "close": null, "last": null, "volume": null, "date": "2021-09-16T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.455, "high": 148.475, "low": 148.365, "close": null, "last": null, "volume": null, "date": "2021-09-15T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.13, "high": 148.205, "low": 148.125, "close": null, "last": null, "volume": null, "date": "2021-09-15T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.035, "high": 148.065, "low": 148.01, "close": null, "last": null, "volume": null, "date": "2021-09-15T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 147.25, "high": 147.265, "low": 147.205, "close": null, "last": null, "volume": null, "date": "2021-09-15T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.24, "high": 149.07, "low": 146.38, "close": 148.12, "last": 148.45, "volume": 655489, "date": "2021-09-15T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.24, "high": 149.07, "low": 146.38, "close": 148.12, "last": 148.16, "volume": 556390, "date": "2021-09-15T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.24, "high": 149.07, "low": 146.38, "close": 148.12, "last": 148.045, "volume": 478321, "date": "2021-09-15T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.24, "high": 149.07, "low": 146.38, "close": 148.12, "last": 147.23, "volume": 324773, "date": "2021-09-15T15:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.24, "high": 149.07, "low": 147, "close": 148.12, "last": 147.53, "volume": 187430, "date": "2021-09-15T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.32, "high": 148.34, "low": 148.32, "close": null, "last": null, "volume": null, "date": "2021-09-15T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 147.75, "high": 147.81, "low": 147.705, "close": null, "last": null, "volume": null, "date": "2021-09-14T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.58, "high": 148.58, "low": 148.48, "close": null, "last": null, "volume": null, "date": "2021-09-14T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.99, "high": 149.155, "low": 148.965, "close": null, "last": null, "volume": null, "date": "2021-09-14T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.73, "high": 151.06, "low": 146.92, "close": 149.55, "last": 148.33, "volume": 1348143, "date": "2021-09-14T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.73, "high": 151.06, "low": 146.92, "close": 149.55, "last": 147.735, "volume": 1117967, "date": "2021-09-14T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.87, "high": 149.885, "low": 149.74, "close": null, "last": null, "volume": null, "date": "2021-09-14T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.73, "high": 151.06, "low": 148.86, "close": 149.55, "last": 149.12, "volume": 728079, "date": "2021-09-14T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.73, "high": 151.06, "low": 149.195, "close": 149.55, "last": 150.285, "volume": 645147, "date": "2021-09-14T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.73, "high": 150.41, "low": 149.73, "close": 149.55, "last": 150.3, "volume": 565, "date": "2021-09-14T13:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.6, "high": 149.6, "low": 149.6, "close": null, "last": null, "volume": null, "date": "2021-09-14T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.275, "high": 149.28, "low": 149.13, "close": null, "last": null, "volume": null, "date": "2021-09-13T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 148.975, "high": 149.08, "low": 148.95, "close": null, "last": null, "volume": null, "date": "2021-09-13T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.03, "high": 150.115, "low": 150.025, "close": null, "last": null, "volume": null, "date": "2021-09-13T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.49, "high": 149.53, "low": 149.4, "close": null, "last": null, "volume": null, "date": "2021-09-13T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.4, "high": 151.4, "low": 148.75, "close": 148.97, "last": 149.245, "volume": 826738, "date": "2021-09-13T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.4, "high": 151.4, "low": 148.83, "close": 148.97, "last": 148.97, "volume": 738390, "date": "2021-09-13T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.4, "high": 151.4, "low": 149.055, "close": 148.97, "last": 150.095, "volume": 652657, "date": "2021-09-13T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.4, "high": 151.4, "low": 149.055, "close": 148.97, "last": 150.07, "volume": 438327, "date": "2021-09-13T15:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.4, "high": 151.4, "low": 149.72, "close": 148.97, "last": 149.89, "volume": 221612, "date": "2021-09-13T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.4, "high": 150.78, "low": 150.32, "close": 148.97, "last": 150.5, "volume": 2399, "date": "2021-09-13T13:00:00.000Z" },
// { "symbol": "AAPL", "open": 149, "high": 149, "low": 149, "close": null, "last": null, "volume": null, "date": "2021-09-11T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.88, "high": 149.945, "low": 149.87, "close": null, "last": null, "volume": null, "date": "2021-09-10T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.97, "high": 150.155, "low": 149.955, "close": null, "last": null, "volume": null, "date": "2021-09-10T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 150.28, "high": 150.42, "low": 150.24, "close": null, "last": null, "volume": null, "date": "2021-09-10T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 149.19, "high": 149.33, "low": 148.93, "close": null, "last": null, "volume": null, "date": "2021-09-10T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.06, "high": 155.48, "low": 148.74, "close": 154.07, "last": 149.87, "volume": 1423889, "date": "2021-09-10T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.06, "high": 155.48, "low": 148.74, "close": 154.07, "last": 149.97, "volume": 1230211, "date": "2021-09-10T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.06, "high": 155.48, "low": 148.74, "close": 154.07, "last": 150.27, "volume": 1064313, "date": "2021-09-10T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.06, "high": 155.48, "low": 148.74, "close": 154.07, "last": 149.2, "volume": 789097, "date": "2021-09-10T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.06, "high": 155.48, "low": 153.995, "close": 154.07, "last": 154.34, "volume": 238196, "date": "2021-09-10T15:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.06, "high": 155.48, "low": 154.78, "close": 154.07, "last": 155.4, "volume": 119912, "date": "2021-09-10T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.06, "high": 154.06, "low": 154.06, "close": null, "last": null, "volume": null, "date": "2021-09-10T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.5, "high": 154.57, "low": 154.48, "close": null, "last": null, "volume": null, "date": "2021-09-09T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.44, "high": 154.47, "low": 154.365, "close": null, "last": null, "volume": null, "date": "2021-09-09T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.9, "high": 154.945, "low": 154.875, "close": null, "last": null, "volume": null, "date": "2021-09-09T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.93, "high": 154.97, "low": 154.9, "close": null, "last": null, "volume": null, "date": "2021-09-09T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.12, "high": 156.105, "low": 154.09, "close": 155.11, "last": 154.495, "volume": 416923, "date": "2021-09-09T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.12, "high": 156.105, "low": 154.255, "close": 155.11, "last": 154.41, "volume": 354409, "date": "2021-09-09T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.12, "high": 156.105, "low": 154.755, "close": 155.11, "last": 154.9, "volume": 295520, "date": "2021-09-09T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.12, "high": 156.105, "low": 154.755, "close": 155.11, "last": 154.93, "volume": 238463, "date": "2021-09-09T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.12, "high": 156.105, "low": 154.79, "close": 155.11, "last": 155.25, "volume": 95968, "date": "2021-09-09T14:00:00.000Z" },
// { "symbol": "AAPL", "open": 155.12, "high": 155.12, "low": 155.12, "close": null, "last": null, "volume": null, "date": "2021-09-09T00:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.745, "high": 154.81, "low": 154.725, "close": null, "last": null, "volume": null, "date": "2021-09-08T23:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.71, "high": 154.8, "low": 154.71, "close": null, "last": null, "volume": null, "date": "2021-09-08T22:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.335, "high": 154.43, "low": 154.29, "close": null, "last": null, "volume": null, "date": "2021-09-08T21:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.325, "high": 154.325, "low": 154.11, "close": null, "last": null, "volume": null, "date": "2021-09-08T20:00:00.000Z" },
// { "symbol": "AAPL", "open": 154.105, "high": 154.32, "low": 154.09, "close": null, "last": null, "volume": null, "date": "2021-09-08T19:00:00.000Z" },
// { "symbol": "AAPL", "open": 157.01, "high": 157.1, "low": 153.97, "close": 156.69, "last": 154.71, "volume": 656446, "date": "2021-09-08T18:00:00.000Z" },
// { "symbol": "AAPL", "open": 157.01, "high": 157.1, "low": 153.97, "close": 156.69, "last": 154.33, "volume": 585888, "date": "2021-09-08T17:00:00.000Z" },
// { "symbol": "AAPL", "open": 157.01, "high": 157.1, "low": 153.97, "close": 156.69, "last": 154.28, "volume": 493348, "date": "2021-09-08T16:00:00.000Z" },
// { "symbol": "AAPL", "open": 157.01, "high": 157.1, "low": 153.97, "close": 156.69, "last": 154.09, "volume": 325281, "date": "2021-09-08T15:00:00.000Z" },
// { "symbol": "AAPL", "open": 157.01, "high": 157.1, "low": 155.51, "close": 156.69, "last": 155.95, "volume": 140315, "date": "2021-09-08T14:00:00.000Z" }])